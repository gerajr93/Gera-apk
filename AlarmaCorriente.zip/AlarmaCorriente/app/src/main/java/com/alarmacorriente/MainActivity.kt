package com.alarmacorriente

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val BG = 0xFF0F172A.toInt()
    private val CARD = 0xFF1E293B.toInt()
    private val MUTED = 0xFF94A3B8.toInt()

    private lateinit var status: TextView
    private lateinit var dot: View

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun shape(c: Int, r: Int, oval: Boolean = false) = GradientDrawable().apply {
        setColor(c)
        if (oval) this.shape = GradientDrawable.OVAL else cornerRadius = dp(r).toFloat()
    }

    private fun refresh() {
        val on = getSharedPreferences("cfg", MODE_PRIVATE).getBoolean("on", false)
        status.text = if (on) "ACTIVO" else "INACTIVO"
        status.setTextColor(if (on) 0xFF22C55E.toInt() else MUTED)
        dot.background = shape(if (on) 0xFF22C55E.toInt() else 0xFF64748B.toInt(), 0, true)
    }

    override fun onResume() { super.onResume(); refresh() }

    @Suppress("DEPRECATION")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        window.decorView.systemUiVisibility = 0
        val p = getSharedPreferences("cfg", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }
        fun add(v: View, top: Int = 0) {
            root.addView(v, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(top) })
        }
        fun label(t: String) = TextView(this).apply {
            text = t; setTextColor(MUTED); textSize = 12f; letterSpacing = 0.1f
            typeface = Typeface.DEFAULT_BOLD
        }
        fun btn(t: String, color: Int, text: Int, f: () -> Unit) = Button(this).apply {
            this.text = t; isAllCaps = false; textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(text); stateListAnimator = null
            background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), shape(color, 14), null)
            minHeight = dp(52)
            setOnClickListener { f() }
        }
        fun field(h: String, key: String) = EditText(this).apply {
            hint = h; setText(p.getString(key, ""))
            setTextColor(Color.WHITE); setHintTextColor(MUTED)
            inputType = InputType.TYPE_CLASS_TEXT
            background = shape(CARD, 12)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }

        add(TextView(this).apply {
            text = "Alarma Corriente"; setTextColor(Color.WHITE); textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
        })
        add(TextView(this).apply {
            text = "Wifi activo y aviso cuando cambia la luz"; setTextColor(MUTED); textSize = 14f
        }, 4)

        // Estado
        dot = View(this)
        status = TextView(this).apply { textSize = 18f; typeface = Typeface.DEFAULT_BOLD }
        val statusCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = shape(CARD, 16)
            setPadding(dp(18), dp(18), dp(18), dp(18))
            addView(dot, LinearLayout.LayoutParams(dp(14), dp(14)).apply { rightMargin = dp(12) })
            addView(status)
        }
        add(statusCard, 22)

        // Configuración
        add(label("CANAL DE TELEGRAM"), 26)
        val group = field("Nombre del canal o grupo", "group")
        val circuit = field("Circuito (ej. R454)", "circuit")
        add(group, 8)
        add(circuit, 10)

        // Acciones
        add(btn("Iniciar", 0xFF22C55E.toInt(), 0xFF052E16.toInt()) {
            p.edit()
                .putString("group", group.text.toString())
                .putString("circuit", circuit.text.toString())
                .putBoolean("on", true).apply()
            startForegroundService(Intent(this, KeepAliveService::class.java))
            refresh()
        }, 20)
        add(btn("Desconectar", 0xFFEF4444.toInt(), Color.WHITE) {
            p.edit().putBoolean("on", false).apply()
            stopService(Intent(this, KeepAliveService::class.java))
            refresh()
        }, 10)
        add(btn("Apagar alarma", 0xFFF59E0B.toInt(), 0xFF451A03.toInt()) {
            stopService(Intent(this, AlarmService::class.java))
        }, 10)
        add(btn("Probar alarma", 0xFF334155.toInt(), Color.WHITE) {
            startForegroundService(Intent(this, AlarmService::class.java).putExtra("msg", "PRUEBA DE ALARMA"))
        }, 10)

        // Permisos
        add(label("CONFIGURACIÓN INICIAL"), 28)
        add(btn("1 · Permiso de notificaciones", CARD, Color.WHITE) {
            if (Build.VERSION.SDK_INT >= 33)
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }, 8)
        add(btn("2 · Acceso a notificaciones", CARD, Color.WHITE) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }, 8)
        add(btn("3 · Batería sin restricciones", CARD, Color.WHITE) {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        }, 8)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG)
            addView(root)
        })
    }
}
