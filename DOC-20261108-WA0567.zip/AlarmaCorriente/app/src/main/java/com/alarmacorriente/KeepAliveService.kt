package com.alarmacorriente

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.concurrent.thread

class KeepAliveService : Service() {
    private var wl: PowerManager.WakeLock? = null
    private var wf: WifiManager.WifiLock? = null
    @Volatile private var running = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == "STOP") {
            getSharedPreferences("cfg", MODE_PRIVATE).edit().putBoolean("on", false).apply()
            stopSelf(); return START_NOT_STICKY
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("keep", "Conexión activa", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 1, Intent(this, KeepAliveService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "keep")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("Wifi activo y vigilando el grupo")
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Desconectar", stop
                ).build()
            ).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)

        if (!running) {
            running = true
            wl = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "alarmacorriente:keep").apply { acquire() }
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            else WifiManager.WIFI_MODE_FULL_HIGH_PERF
            wf = wm.createWifiLock(mode, "alarmacorriente:wifi").apply { acquire() }
            thread {
                while (running) {
                    ping(wm)
                    try { Thread.sleep(5000) } catch (_: InterruptedException) {}
                }
            }
        }
        return START_STICKY
    }

    @Suppress("DEPRECATION")
    private fun ping(wm: WifiManager) {
        val g = wm.dhcpInfo.gateway
        val ip = if (g == 0) "192.168.1.1"
        else "${g and 255}.${g shr 8 and 255}.${g shr 16 and 255}.${g shr 24 and 255}"
        try { Socket().use { it.connect(InetSocketAddress(ip, 80), 2000) } } catch (_: Exception) {}
    }

    override fun onDestroy() {
        running = false
        wl?.let { if (it.isHeld) it.release() }
        wf?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
