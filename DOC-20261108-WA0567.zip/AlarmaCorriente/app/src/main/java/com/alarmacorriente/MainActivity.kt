package com.alarmacorriente

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val group = EditText(this).apply {
            hint = "Nombre del grupo de Telegram"
            setText(p.getString("group", ""))
        }
        val circuit = EditText(this).apply {
            hint = "Circuito (opcional, ej. 12)"
            setText(p.getString("circuit", ""))
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t
            setOnClickListener { f() }
            root.addView(this, LinearLayout.LayoutParams(MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        root.addView(group)
        root.addView(circuit)

        btn("1. Permiso de notificaciones") {
            if (Build.VERSION.SDK_INT >= 33)
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn("2. Acceso a notificaciones (activar esta app)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        btn("3. Batería: sin restricciones") {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        }
        btn("INICIAR (wifi activo + vigilar grupo)") {
            p.edit()
                .putString("group", group.text.toString())
                .putString("circuit", circuit.text.toString())
                .putBoolean("on", true).apply()
            startForegroundService(Intent(this, KeepAliveService::class.java))
        }
        btn("DESCONECTAR") {
            p.edit().putBoolean("on", false).apply()
            stopService(Intent(this, KeepAliveService::class.java))
        }
        btn("APAGAR ALARMA") { stopService(Intent(this, AlarmService::class.java)) }
        btn("Probar alarma") {
            startForegroundService(Intent(this, AlarmService::class.java).putExtra("msg", "PRUEBA DE ALARMA"))
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
