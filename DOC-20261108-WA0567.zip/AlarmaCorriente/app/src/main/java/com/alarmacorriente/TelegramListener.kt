package com.alarmacorriente

import android.app.Notification
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.text.Normalizer

class TelegramListener : NotificationListenerService() {
    private var lastBody = ""
    private var lastTime = 0L

    private fun norm(s: String) =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in PKGS) return
        if (sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        if (!p.getBoolean("on", false)) return

        val e = sbn.notification.extras
        val head = norm("${e.getCharSequence(Notification.EXTRA_TITLE) ?: ""} ${e.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE) ?: ""}")
        val body = norm("${e.getCharSequence(Notification.EXTRA_TEXT) ?: ""} ${e.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ""}")

        val group = norm(p.getString("group", "")!!.trim())
        val circuit = norm(p.getString("circuit", "")!!.trim())
        if (group.isNotEmpty() && !head.contains(group) && !body.contains(group)) return
        if (circuit.isNotEmpty() && !body.contains(circuit)) return

        val kind = when {
            OFF.any { body.contains(it) } -> "SE FUE LA LUZ"
            ON.any { body.contains(it) } -> "LLEGÓ LA LUZ"
            else -> return
        }
        val now = System.currentTimeMillis()
        if (body == lastBody && now - lastTime < 120_000) return
        lastBody = body; lastTime = now

        startForegroundService(Intent(this, AlarmService::class.java).putExtra("msg", kind))
    }

    companion object {
        val PKGS = setOf("org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram")
        // OFF se evalúa primero: "ya no hay corriente" no debe contar como llegada
        val OFF = listOf("se fue", "se fueron", "se va", "quitaron", "quito la", "apagon", "sin corriente", "sin luz", "no hay corriente", "no hay luz", "se afecto", "deficit de generacion")
        val ON = listOf("llego", "llegaron", "dieron", "vino", "volvio", "hay corriente", "hay luz", "ya hay", "restablecido", "restablecen")
    }
}
